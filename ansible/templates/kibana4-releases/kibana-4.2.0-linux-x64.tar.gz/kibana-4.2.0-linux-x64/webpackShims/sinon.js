'use strict';

require('script!node_modules/sinon/pkg/sinon.js');
module.exports = window.sinon;
